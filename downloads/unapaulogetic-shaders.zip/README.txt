SHADERS
Paul Rozenboim - unapaulogetic.art

6 fragment shaders, each in three formats. Free to use, including
at paid work. A credit is welcome and not required. You do not need to
ask first.


WHAT IS IN HERE

  touchdesigner/   .frag - for a GLSL TOP
  isf/             .fs   - for Resolume, VDMX, Millumin, CoGe
  webgl/           .frag - for a web page


TOUCHDESIGNER

  1. Add a GLSL TOP.
  2. Open its Pixel Shader and paste the file in.
  3. On the TOP's Vectors page, add a uniform named uTime, and point it at
     absTime.seconds. Nothing renders until you do this - a shader with no
     clock is a still frame.
  4. For the shaders that follow the pointer, add a vec4 named uMouse and
     feed x and y from a Mouse In CHOP, normalised 0 to 1.

  The top of each file repeats these steps.


RESOLUME AND OTHER ISF HOSTS

  Drop the .fs file into the ISF folder and it appears as a source.

    Resolume   Documents/Resolume Arena/Extra Effects/ISF
    VDMX       Library/Graphics/ISF
    Millumin   Documents/Millumin/ISF

  Restart the host if it does not show up. Shaders that follow the pointer
  expose a "mouse" point control in the host's own interface.


A WEB PAGE

  The webgl/ files are GLSL ES 1.00, which is what WebGL1 takes. They expect
  four uniforms: iResolution (vec3), iTime (float), iMouse (vec4) and
  iFrame (int). viewer.js in the repository is a working example of feeding
  them, and it is about a hundred lines.


THE SHADERS

  Abstract Lines Rain
    Just some abstract lines falling down

  Cartwheel Effect
    The famous Wagon Cartwheel Effect with lines

  Data Stream Rain
    Some data raining. Falling Pixels

  Interactive Data Rain
    Data blocks rain, controllable with mouse drags
    Follows the pointer.

  Moire Drift
    Two line gratings turning against each other. Everything you see is the beat between them.
    Follows the pointer.

  Lens Grid
    Graph paper with something invisible moving underneath it. The grid never changes, only the coordinates.
    Follows the pointer.


All three versions are generated from one source by tools/port.mjs, so they
never drift apart. Sources and originals:

  https://github.com/paulrozenboim/shaders
  https://www.shadertoy.com/user/paulrozenboim
